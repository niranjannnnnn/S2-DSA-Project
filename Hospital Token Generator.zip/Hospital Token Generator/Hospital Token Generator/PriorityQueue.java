import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Stack;



public class PriorityQueue {

	LinkedList list = new LinkedList(); 
	
    public void insert(Node node,int doctorNumber) throws IOException  {
    	
    	Stack<Node> stack = new Stack<Node>();
    	
    
    	
        if(doctorNumber == 1)
        {

        	if(new File("dr1.txt").length() >= 1) 
        	{
        		Scanner scan = new Scanner(new File("dr1.txt"));
        		
        		while(scan.hasNext())
        		{
        			
        		String temp[] = scan.nextLine().split(" ");// split the line into two parts
        	
        		list.add(new Node(temp[0].split(".").length!=1?temp[0].replace('.',' '):temp[0],temp[3].charAt(0),Integer.parseInt(temp[1]),Float.parseFloat(temp[2]),temp[4]));// add the node to the linked list
        	
        		}
        		list.add(node);
        	}
        		
        	else 
        	{
        		list.add(node);
        	}
        	
        	FileWriter dr1 = new FileWriter(new File("dr1.txt"));
        	
        
        	
        	
        	for(int i =  list.size()-1; i>=0 ;i--)// loop through linked list
        	{
        		if(list.get(i).status == 'N')// if the node is not in the queue
        		{
        			stack.push(list.get(i));// add the node to the stack
        			list.remove(i);// remove the node from the linked list
        			
        		}
        	}
        	
        	
        	
        	for(int i =  list.size()-1; i>=0 ;i--)// loop through linked list 
        	{
        		
        			stack.push(list.get(i));// add the node to the stack
        			
        		
        	}
        	
        	while(!stack.isEmpty()) {// loop through the stack
        		Node temp = stack.pop();// pop the node from the stack
        		String condition = (temp.status=='S'?"Serious":"Normal");// create a string to represent the condition
        		String tempName = temp.name.split(" ").length!=1?temp.name.replace(' ', '.'):temp.name;// create a string to represent the name
        		dr1.write(tempName+" "+temp.age+" "+temp.weight+" "+condition+" "+temp.time+"\n");// write the node to the file
        	}
        	
        	dr1.close();
       
        }
        else if(doctorNumber == 2)
        {
        	
        	if(new File("dr2.txt").length() >= 1)
        	{
        		Scanner scan = new Scanner(new File("dr2.txt"));
        		
        		while(scan.hasNext())
        		{
        			
        		String temp[] = scan.nextLine().split(" ");
        	
        		list.add(new Node(temp[0].split(".").length!=1?temp[0].replace('.',' '):temp[0],temp[3].charAt(0),Integer.parseInt(temp[1]),Float.parseFloat(temp[2]),temp[4]));// add the node to the linked list
			
        	
        		}
        		list.add(node);
        	}
        		
        	else 
        	{
        		list.add(node);
        	}
        	
        	FileWriter dr2 = new FileWriter(new File("dr2.txt"));
        	
        
        	
        	
        	for(int i =  list.size()-1; i>=0 ;i--)// loop through linked list 
        	{
        		if(list.get(i).status == 'N')// if the node is not in the queue 
        		{
        			stack.push(list.get(i));// add the node to the stack
        			list.remove(i);// remove the node from the linked list
        			
        		}
        	}
        	
        	
        	
        	for(int i =  list.size()-1; i>=0 ;i--)// loop through linked list 
        	{
        		
        			stack.push(list.get(i));// add the node to the stack
        			
        		
        	}
        	
        	while(!stack.isEmpty()) {// loop through the stack
        		Node temp = stack.pop();// pop the node from the stack
        		String condition = (temp.status=='S'?"Serious":"Normal");// create a string to represent the condition
        		String tempName = temp.name.split(" ").length!=1?temp.name.replace(' ', '.'):temp.name;// create a string to represent the name
        		dr2.write(tempName+" "+temp.age+" "+temp.weight+" "+condition+" "+temp.time+"\n");// write the node to the file
        	}
        	
        	dr2.close();
        }
        else if(doctorNumber == 3)
        {

        	if(new File("dr3.txt").length() >= 1)// if file is not empty
        	{
        		Scanner scan = new Scanner(new File("dr3.txt"));// create a new scanner
        		
        		while(scan.hasNext())// loop through the file
				
        		{
        		
        		String temp[] = scan.nextLine().split(" ");// split the line into two parts
        	
        		list.add(new Node(temp[0].split(".").length!=1?temp[0].replace('.',' '):temp[0],temp[3].charAt(0),Integer.parseInt(temp[1]),Float.parseFloat(temp[2]),temp[4]));// add the node to the linked list
			
        	
        		}
        		list.add(node);
        	}
        		
        	else 
        	{
        		list.add(node);
        	}
        	
        	FileWriter dr3 = new FileWriter(new File("dr3.txt"));// create a new file writer
        	
        
        	
        	
        	for(int i =  list.size()-1; i>=0 ;i--)// loop through linked list
        	{
        		if(list.get(i).status == 'N')// if node not in queue 
        		{
        			stack.push(list.get(i));// add the node to the stack
        			list.remove(i);// remove the node from the linked list
        			
        		}
        	}
        	
        	
        	
        	for(int i =  list.size()-1; i>=0 ;i--)// loop through linked list 
        	{
        		
        			stack.push(list.get(i));// add the node to the stack
        			
        		
        	}
        	
        	while(!stack.isEmpty()) {// loop through the stack
        		Node temp = stack.pop();// pop the node from the stack
        		String condition = (temp.status=='S'?"Serious":"Normal");// create a string to represent the condition
        		String tempName = temp.name.split(" ").length!=1?temp.name.replace(' ', '.'):temp.name;// create a string to represent the name
        		dr3.write(tempName+" "+temp.age+" "+temp.weight+" "+condition+" "+temp.time+"\n");// write the node to the file
        	}
        	
        	dr3.close();
        }
        	
    	

    }

  
  
  
}
