
class Node{
	
		String name,time;
		char status;
		int age;
		float weight;
		
		
		Node next;
		
		public Node(String name,char status,int age,float weight,String time)
		{
			this.name = name;
			this.status = status;
			
			this.age = age;
			this.weight = weight;
			this.time  = time;
			next = null;
		}

		

	
	
	
	}

